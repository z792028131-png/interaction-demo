import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import './App.css'

import assistantSource from '../assets/figma-assistant-source.png'
import background from '../assets/figma-background.svg'
import greeting from '../assets/figma-greeting.svg'
import heroCopyMain from '../assets/hero-copy-main.png'
import inputSparkle from '../assets/figma-input-sparkle.svg'
import officeStroke from '../assets/figma-office-stroke.svg'
import sendIcon from '../assets/figma-send.svg'
import starEmpty from '../assets/figma-star-empty.svg'
import starFilled from '../assets/figma-star-filled.svg'
import tagHighlight from '../assets/figma-tag-highlight.svg'
import tagTail from '../assets/figma-tag-tail.svg'
import tagTailActive from '../assets/figma-tag-tail-active.svg'
import union from '../assets/figma-union.svg'

const DESIGN_WIDTH = 402
const DESIGN_HEIGHT = 999

import archiveIcon from '../assets/icon-process-archive.png'
import ipContractIcon from '../assets/icon-process-ip-contract.png'
import overtimeIcon from '../assets/icon-process-overtime.png'
import salaryIcon from '../assets/icon-process-salary.png'
import softwareIcon from '../assets/icon-process-software.png'
import vehicleIcon from '../assets/icon-process-vehicle-purchase.png'
import vpnIcon from '../assets/icon-process-vpn.png'
import weddingIcon from '../assets/icon-process-wedding-benefit.png'
import allProcessesIcon from '../assets/icon-section-all-processes.png'
import favoritesIcon from '../assets/icon-section-favorites.png'

const processData = [
  {
    id: 'software',
    category: '信息技术服务',
    title: '信息技术服务-07-正版系统&软件申请',
    description: '申请正版系统或办公、业务软件使用权限',
    icon: softwareIcon,
    isFavorite: true,
  },
  {
    id: 'overtime',
    category: '行政管理',
    title: '行政管理-10-加班申请',
    description: '提交加班申请或补录加班信息',
    icon: overtimeIcon,
    isFavorite: true,
  },
  {
    id: 'salary',
    category: '财务报销',
    title: '财务报销-17-工资支付申请',
    description: '发起工资支付申请并完成审批',
    icon: salaryIcon,
    isFavorite: true,
  },
  {
    id: 'vehicle',
    category: '采购供应链',
    title: '采购供应链-02-车辆采购申请',
    description: '提交车辆采购需求并发起审批。',
    icon: vehicleIcon,
    isFavorite: true,
  },
  {
    id: 'ip-contract',
    category: '法务合规',
    title: '法务合规-03-知识产权合同',
    description: '发起知识产权类合同审批与管理。',
    icon: ipContractIcon,
    isFavorite: true,
  },
  {
    id: 'vpn',
    category: '其他',
    title: '其他-07-VPN账号权限申请',
    description: '申请 VPN 账号或内部系统访问权限。',
    icon: vpnIcon,
    isFavorite: true,
  },
  {
    id: 'wedding',
    category: '人力资源',
    title: '人力资源-23-结婚礼金/慰问金申请',
    description: '申请结婚礼金或员工慰问金',
    icon: weddingIcon,
    isFavorite: true,
  },
  {
    id: 'archive',
    category: '行政管理',
    title: '行政管理-05-档案查阅申请',
    description: '申请查阅或调阅相关档案资料',
    icon: archiveIcon,
    isFavorite: false,
  },
  {
    id: 'security-access',
    category: '安全合规',
    title: '安全合规-01-系统安全访问申请',
    description: '申请系统安全访问权限并完成审批',
    icon: vpnIcon,
    isFavorite: true,
  },
]

const categories = [
  '全部',
  '行政管理',
  '人力资源',
  '财务报销',
  '信息技术服务',
  '法务合规',
  '采购供应链',
  '安全合规',
  '其他',
]

function App() {
  const [screenScale, setScreenScale] = useState(() => getScreenScale())
  const [inputValue, setInputValue] = useState('')
  const [submittedQuery, setSubmittedQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('全部')
  const [toast, setToast] = useState('')
  const [processes, setProcesses] = useState(processData)
  const [searchHistory, setSearchHistory] = useState([])
  const [removingFavoriteIds, setRemovingFavoriteIds] = useState(() => new Set())
  const [contentHeight, setContentHeight] = useState(DESIGN_HEIGHT)
  const mobileScreenRef = useRef(null)
  const allProcessListRef = useRef(null)
  const categoryScrollRef = useRef(null)
  const categoryTabRefs = useRef(new Map())

  const favoriteProcesses = useMemo(
    () => processes.filter(({ isFavorite }) => isFavorite),
    [processes],
  )

  const favoriteDisplayProcesses = useMemo(
    () =>
      processes.filter(
        (item) =>
          (item.isFavorite || removingFavoriteIds.has(item.id)) &&
          matchesSearch(item, submittedQuery),
      ),
    [processes, removingFavoriteIds, submittedQuery],
  )

  const favoriteColumns = useMemo(() => {
    if (favoriteDisplayProcesses.length === 0) return []
    if (favoriteDisplayProcesses.length <= 4) return [favoriteDisplayProcesses]

    return Array.from(
      { length: Math.ceil(favoriteDisplayProcesses.length / 4) },
      (_, columnIndex) => favoriteDisplayProcesses.slice(columnIndex * 4, columnIndex * 4 + 4),
    )
  }, [favoriteDisplayProcesses])

  const isCompactFavorites = favoriteDisplayProcesses.length >= 5
  const favoriteGridWidth = isCompactFavorites
    ? favoriteColumns.length * 295 + Math.max(0, favoriteColumns.length - 1) * 8 + 16
    : 370

  const visibleProcesses = useMemo(
    () =>
      processes.filter(
        (item) =>
          (selectedCategory === '全部' || item.category === selectedCategory) &&
          matchesSearch(item, submittedQuery),
      ),
    [processes, selectedCategory, submittedQuery],
  )

  useEffect(() => {
    const handleResize = () => setScreenScale(getScreenScale())

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  useLayoutEffect(() => {
    const main = mobileScreenRef.current
    const allProcessList = allProcessListRef.current
    if (!main || !allProcessList) return

    const listBottom = (allProcessList.getBoundingClientRect().bottom + window.scrollY) / screenScale
    const nextContentHeight = Math.max(DESIGN_HEIGHT, Math.ceil(listBottom))
    setContentHeight((current) => (current === nextContentHeight ? current : nextContentHeight))
  }, [screenScale, selectedCategory, visibleProcesses.length, favoriteProcesses.length])

  const notify = (message) => {
    setToast(message)
    window.clearTimeout(notify.timer)
    notify.timer = window.setTimeout(() => setToast(''), 2200)
  }

  const toggleFavorite = (id, title) => {
    const target = processes.find((item) => item.id === id)
    if (!target) return

    const nextFavorite = !target.isFavorite
    setProcesses((current) =>
      current.map((item) => (item.id === id ? { ...item, isFavorite: nextFavorite } : item)),
    )

    if (target.isFavorite) {
      setRemovingFavoriteIds((current) => new Set(current).add(id))
      window.setTimeout(() => {
        setRemovingFavoriteIds((current) => {
          const next = new Set(current)
          next.delete(id)
          return next
        })
      }, 180)
    } else {
      setRemovingFavoriteIds((current) => {
        const next = new Set(current)
        next.delete(id)
        return next
      })
    }

    notify(nextFavorite ? `已收藏：${title}` : `已取消收藏：${title}`)
  }

  const handleSubmit = (event) => {
    event.preventDefault()
    const trimmedQuery = inputValue.trim()
    setSubmittedQuery(trimmedQuery)
    if (!trimmedQuery) {
      notify('请先告诉我你想办理什么')
      return
    }

    setSearchHistory((current) => [...current, trimmedQuery])
    notify(`正在为你创建：${trimmedQuery}`)
  }

  const handleInputChange = (event) => {
    const nextValue = event.target.value
    setInputValue(nextValue)
    if (!nextValue.trim()) setSubmittedQuery('')
  }

  const handleCategoryClick = (category) => {
    setSelectedCategory(category)
    window.requestAnimationFrame(() => {
      const scroller = categoryScrollRef.current
      const selectedTab = categoryTabRefs.current.get(category)
      if (!scroller || !selectedTab) return

      const maxScroll = Math.max(0, scroller.scrollWidth - scroller.clientWidth)
      const selectedCenter = selectedTab.offsetLeft + selectedTab.offsetWidth / 2
      const targetScrollLeft = Math.min(
        Math.max(0, selectedCenter - scroller.clientWidth / 2),
        maxScroll,
      )

      scroller.scrollTo({ left: targetScrollLeft, behavior: 'smooth' })
    })
    notify(category === '全部' ? '已显示全部流程' : `已筛选：${category}`)
  }

  const viewportStyle = {
    '--screen-scale': screenScale,
    '--screen-height': `${contentHeight * screenScale}px`,
    '--content-height': `${contentHeight}px`,
  }

  return (
    <div className="viewport-shell" style={viewportStyle}>
      <div className="background-layer" aria-hidden="true">
        <img className="page-background" src={background} alt="" />
      </div>

      <main ref={mobileScreenRef} className="mobile-screen" data-node-id="1983:1066">

      <img className="office-stroke" src={officeStroke} alt="" />
      <img className="union-decoration" src={union} alt="" />

      <div className="assistant-main" aria-hidden="true">
        <img src={assistantSource} alt="" />
      </div>
      <div className="assistant-detail" aria-hidden="true">
        <img src={assistantSource} alt="" />
      </div>

      <section className="greeting" data-node-id="1983:1217">
        <div className="greeting-mark-frame" aria-hidden="true">
          <img className="greeting-mark" src={greeting} alt="" />
        </div>
        <img
          className="hero-copy-main"
          src={heroCopyMain}
          alt="让每一次发起，都清晰高效"
        />
      </section>

      <form className="assistant-input" onSubmit={handleSubmit} data-node-id="1983:1190">
        <div className="assistant-prompt">
          <img src={inputSparkle} alt="" />
          <input
            value={inputValue}
            onChange={handleInputChange}
            placeholder="告诉我你想办理什么，例如“我想请3天假”"
            aria-label="告诉我你想办理什么"
          />
        </div>
        <div className={`assistant-actions ${searchHistory.length ? 'has-history' : 'no-history'}`}>
          {searchHistory.length ? (
            <div className="quick-chips" aria-label="最近发起">
              <span className="recent-label">最近发起：</span>
              <div className="quick-chip-list">
                {searchHistory.map((historyItem, historyIndex) => (
                  <span key={`${historyItem}-${historyIndex}`} className="quick-chip">
                    {historyItem}
                  </span>
                ))}
              </div>
            </div>
          ) : null}
          <div className="input-tools">
            <button type="submit" className="send-button" aria-label="发送">
              <img src={sendIcon} alt="" />
            </button>
          </div>
        </div>
      </form>

      <section className="favorites-section" data-node-id="1983:1079">
        <SectionHeading icon={favoritesIcon} label={`我的收藏 (${favoriteProcesses.length})`} />
        <div className="favorite-scroll">
          {favoriteDisplayProcesses.length === 0 ? (
            <div className="favorite-empty">暂无数据</div>
          ) : (
            <div
              className={`favorite-grid ${isCompactFavorites ? 'is-compact' : 'is-single-column'}`}
              data-node-id="1983:1084"
              style={{ width: `${favoriteGridWidth}px` }}
            >
              {favoriteColumns.map((column, columnIndex) => (
                <div
                  className={`favorite-column ${isCompactFavorites ? '' : 'is-single-column'}`}
                  key={columnIndex}
                >
                  {column.map((item) => (
                    <ProcessCard
                      key={item.id}
                      item={item}
                      isFavorite={item.isFavorite}
                      isRemoving={removingFavoriteIds.has(item.id)}
                      onToggleFavorite={toggleFavorite}
                      onOpen={() => notify(`正在打开：${item.title}`)}
                    />
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="all-processes-section" data-node-id="1983:1135">
        <SectionHeading icon={allProcessesIcon} label={`全部流程 (${processes.length})`} />
        <div ref={categoryScrollRef} className="category-scroll" data-node-id="1983:1140">
          {categories.map((category) => (
            <CategoryTag
              key={category}
              label={category}
              active={selectedCategory === category}
              nodeRef={(node) => {
                if (node) categoryTabRefs.current.set(category, node)
                else categoryTabRefs.current.delete(category)
              }}
              onClick={() => handleCategoryClick(category)}
            />
          ))}
        </div>
        <div ref={allProcessListRef} className="all-process-list" data-node-id="1983:1162">
          {visibleProcesses.length === 0 ? (
            <div className="process-empty">暂无数据</div>
          ) : (
            visibleProcesses.map((item) => (
              <ProcessCard
                key={item.id}
                item={item}
                isFavorite={item.isFavorite}
                onToggleFavorite={toggleFavorite}
                onOpen={() => notify(`正在打开：${item.title}`)}
              />
            ))
          )}
        </div>
      </section>

      {toast ? <div className="toast">{toast}</div> : null}
      </main>
    </div>
  )
}

function getScreenScale() {
  return typeof window === 'undefined' ? 1 : window.innerWidth / DESIGN_WIDTH
}

function matchesSearch(process, searchQuery) {
  if (!searchQuery) return true

  const searchableText = `${process.title} ${process.description || ''}`.toLowerCase()
  return searchableText.includes(searchQuery.toLowerCase())
}

function SectionHeading({ icon, label }) {
  return (
    <div className="section-heading">
      <img src={icon} alt="" />
      <h2>{label}</h2>
    </div>
  )
}

function CategoryTag({ label, active, nodeRef, onClick }) {
  return (
    <button
      ref={nodeRef}
      type="button"
      className={`category-tag ${active ? 'active' : ''}`}
      onClick={onClick}
    >
      <img className="category-tail" src={active ? tagTailActive : tagTail} alt="" />
      <span className="category-body">{label}</span>
      {active ? <img className="category-highlight" src={tagHighlight} alt="" /> : null}
    </button>
  )
}

function ProcessCard({ item, isFavorite, isRemoving = false, onToggleFavorite, onOpen }) {
  return (
    <article
      className={`process-card ${isRemoving ? 'is-removing' : ''}`}
      onClick={onOpen}
      role="button"
      tabIndex={0}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') onOpen()
      }}
    >
      <div className="process-copy">
        <div className="process-title-row">
          <h3>{item.title}</h3>
          <button
            type="button"
            className="favorite-button"
            onClick={(event) => {
              event.stopPropagation()
              onToggleFavorite(item.id, item.title)
            }}
            aria-label={isFavorite ? `取消收藏${item.title}` : `收藏${item.title}`}
          >
            <img src={isFavorite ? starFilled : starEmpty} alt="" />
          </button>
        </div>
      </div>
    </article>
  )
}

export default App
