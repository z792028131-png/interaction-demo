# OA新建页面 Demo 源码

React + Vite 单页交互原型，发布目录为当前项目文件夹的上一层（`oa-new-page/`）。Vite 使用相对资源路径，支持 GitHub Pages 子路径部署。

## 本地运行

```sh
pnpm install
pnpm dev
```

## 构建发布文件

```sh
pnpm build
```

构建先生成 `source/dist/`，再将发布文件复制到 `oa-new-page/` 根目录。演示中的流程数据为静态示例，不连接真实业务系统。
