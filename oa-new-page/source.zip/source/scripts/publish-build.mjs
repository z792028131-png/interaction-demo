import { cp, rm } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const scriptsDirectory = dirname(fileURLToPath(import.meta.url))
const sourceDirectory = resolve(scriptsDirectory, '..')
const outputDirectory = resolve(sourceDirectory, 'dist')
const projectDirectory = resolve(sourceDirectory, '..')

await Promise.all([
  rm(resolve(projectDirectory, 'assets'), { recursive: true, force: true }),
  rm(resolve(projectDirectory, 'index.html'), { force: true }),
  rm(resolve(projectDirectory, 'favicon.svg'), { force: true }),
  rm(resolve(projectDirectory, 'icons.svg'), { force: true }),
])
await cp(outputDirectory, projectDirectory, { recursive: true })
console.log(`GitHub Pages files copied to ${projectDirectory}`)
